class Model
{
	constructor()
	{
		this.sprites = [];
		this.cameraPos = 0;
		this.mario = new Mario(200, 200, this);
		this.sprites.push(this.mario)
	// 	this.sprites.push(new Sprite(200, 100, "brick.png", Sprite.prototype.sit_still, Sprite.prototype.ignore_click));
	// 	this.turtle = new Sprite(50, 50, "coin.png", Sprite.prototype.go_toward_destination, Sprite.prototype.set_destination);
	// 	this.sprites.push(this.turtle);
	//  this.sprites.push(new Sprite(0,0,100,100,this))

	// }
	}

	update()
	{
		for(let i = 0; i < this.sprites.length; i++)
		{
			if(this.sprites[i] === undefined) return;
			this.sprites[i].update();
		}
	}
}